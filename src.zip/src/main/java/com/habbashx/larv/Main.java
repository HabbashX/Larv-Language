package com.habbashx.larv;

import com.habbashx.larv.error.LarvError;
import com.habbashx.larv.lexer.Lexer;
import com.habbashx.larv.lexer.Token;
import com.habbashx.larv.parser.Parser;
import com.habbashx.larv.parser.ast.statement.Statement;
import com.habbashx.larv.runtime.Interpreter;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class Main {

    public static void main(String @NotNull [] args) {
        
        if (args.length < 0) return;

        switch(args[0]) {
            case "--version" -> System.out.println("Larv Version: 1.0.0-beta");
            case "--creator" -> System.out.println("""
                    Creator: Abd Allah Al Habbash
                    or you can call me Habbash
                    
                    github: Habbashx
                    instagram: abdallah_alhabbash
                    """);
            case "run" -> {
                if (args.length < 1) {
                    System.out.println("please provide file name");
                    return;
                }
                String filePath = args[1];
                runLarv(filePath);
            }
        }

    }

    private static void runLarv(final String filePath){
        String source;

        final Path file = Path.of(filePath).toAbsolutePath().normalize();

        try {
            source = Files.readString(file);
        } catch (IOException e) {
            System.err.println("Error Cannot read file'" + filePath + "': " + e.getMessage());
            System.exit(1);
            return;
        }

        try {
            final Lexer lexer  = new Lexer(source);
            final List<Token> tokens = lexer.tokenize();

            Parser parser  = new Parser(tokens);
            List<Statement> program = parser.parse();

            Path projectRoot = file.getParent() != null ? file.getParent() : Path.of(".");
            Interpreter interpreter = new Interpreter(projectRoot);
            interpreter.execute(program);

        } catch (LarvError e) {
            System.err.println(e.format());
            System.exit(1);

        } catch (Exception e) {
            System.err.println("Internal Error " + e.getMessage());
            System.err.println("Please report this bug. Java detail: " + e.getClass().getSimpleName());
            System.exit(1);
        }
    }

}
