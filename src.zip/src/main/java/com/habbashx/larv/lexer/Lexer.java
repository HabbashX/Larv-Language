package com.habbashx.larv.lexer;

import com.habbashx.larv.error.LarvError;

import java.util.ArrayList;
import java.util.List;

public class Lexer {

    private final String      source;
    private final List<Token> tokens = new ArrayList<>();

    private int start       = 0;
    private int current     = 0;
    private int line        = 1;
    private int lineStart   = 0;

    public Lexer(String source) {
        this.source = source;
    }

    public List<Token> tokenize() {
        while (!isAtEnd()) {
            start = current;
            scanToken();
        }
        tokens.add(new Token(TokenType.EOF, "", line, col()));
        return tokens;
    }

    private int col() {
        return start - lineStart + 1;
    }

    private void scanToken() {
        char c = advance();

        switch (c) {
            case '(' -> addToken(TokenType.LPAREN);
            case ')' -> addToken(TokenType.RPAREN);
            case '{' -> addToken(TokenType.LBRACE);
            case '}' -> addToken(TokenType.RBRACE);
            case ',' -> addToken(TokenType.COMMA);
            case ';' -> addToken(TokenType.SEMICOLON);
            case '[' -> addToken(TokenType.LBRACKET, "[");
            case ']' -> addToken(TokenType.RBRACKET, "]");
            case ':' -> addToken(TokenType.COLON,    ":");
            case '.' -> addToken(TokenType.DOT,      ".");

            case '+' -> { if (match('+')) addToken(TokenType.PLUS_PLUS);   else addToken(TokenType.PLUS); }
            case '-' -> { if (match('-')) addToken(TokenType.MINUS_MINUS); else addToken(TokenType.MINUS); }
            case '*' -> addToken(TokenType.STAR);
            case '/' -> {
                if (match('/')) { while (!isAtEnd() && peek() != '\n') advance(); }
                else addToken(TokenType.SLASH);
            }
            case '=' -> { if (match('=')) addToken(TokenType.EQEQ);  else addToken(TokenType.EQUAL); }
            case '!' -> {
                if (match('=')) addToken(TokenType.NOTEQ);
                else throw new LarvError(
                        "Unexpected character '!' — did you mean '!='?", line, col(), LarvError.Kind.LEXER);
            }
            case '<' -> { if (match('=')) addToken(TokenType.LTE); else addToken(TokenType.LT); }
            case '>' -> { if (match('=')) addToken(TokenType.GTE); else addToken(TokenType.GT); }

            case '"' -> string();

            case '\n' -> { line++; lineStart = current; }   // reset column counter
            case ' ', '\r', '\t' -> {}

            default -> {
                if (isDigit(c))      number();
                else if (isAlpha(c)) identifier();
                else throw new LarvError(
                            "Unexpected character '" + c + "'", line, col(), LarvError.Kind.LEXER);
            }
        }
    }

    /**
     * Scans a string literal that started with the opening {@code "} (already consumed).
     *
     * <p>Two kinds of content are allowed inside the string without escaping:</p>
     * <ul>
     *   <li>Normal characters — appended as-is.</li>
     *   <li>A {@code "} that appears <em>inside balanced parentheses</em> — treated as
     *       part of the string value, not the closing delimiter.  This lets involve-args
     *       be written naturally, e.g.
     *       {@code "java.io.FileWriter("example.txt")"} without any escaping.</li>
     * </ul>
     * Standard backslash escapes ({@code \"}, {@code \\}, {@code \n}, …) are also
     * supported for the cases where you do want to escape.
     */
    private void string() {
        int startLine = line;
        int startCol  = col();
        StringBuilder sb = new StringBuilder();
        int parenDepth = 0;

        while (!isAtEnd()) {
            char c = peek();

            if (c == '"' && parenDepth == 0) break;

            if (c == '\n') { line++; lineStart = current + 1; }

            if (c == '\\' && current + 1 < source.length()) {
                advance(); // consume backslash
                char escaped = advance();
                switch (escaped) {
                    case '"'  -> sb.append('"');
                    case '\\' -> sb.append('\\');
                    case 'n'  -> sb.append('\n');
                    case 't'  -> sb.append('\t');
                    case 'r'  -> sb.append('\r');
                    default   -> { sb.append('\\'); sb.append(escaped); }
                }
                continue;
            }

            if (c == '(') parenDepth++;
            else if (c == ')' && parenDepth > 0) parenDepth--;

            sb.append(advance());
        }

        if (isAtEnd()) throw new LarvError(
                "Unterminated string — opened here", startLine, startCol, LarvError.Kind.LEXER);
        advance();
        addToken(TokenType.STRING, sb.toString());
    }

    private void number() {
        while (!isAtEnd() && isDigit(peek())) advance();
        if (!isAtEnd() && peek() == '.' && current + 1 < source.length()
                && isDigit(source.charAt(current + 1))) {
            advance();
            while (!isAtEnd() && isDigit(peek())) advance();
        }
        addToken(TokenType.NUMBER, source.substring(start, current));
    }

    private void identifier() {
        while (!isAtEnd() && isAlphaNumeric(peek())) advance();
        String text = source.substring(start, current);
        TokenType type = switch (text) {
            case "var"      -> TokenType.VAR;
            case "const"    -> TokenType.CONST;
            case "if"       -> TokenType.IF;
            case "else"     -> TokenType.ELSE;
            case "while"    -> TokenType.WHILE;
            case "for"      -> TokenType.FOR;
            case "func"     -> TokenType.FUNC;
            case "return"   -> TokenType.RETURN;
            case "break"    -> TokenType.BREAK;
            case "continue" -> TokenType.CONTINUE;
            case "class"    -> TokenType.CLASS;
            case "new"      -> TokenType.NEW;
            case "this"     -> TokenType.THIS;
            case "include"  -> TokenType.INCLUDE;
            case "from"     -> TokenType.FROM;
            case "involve"  -> TokenType.INVOLVE;
            case "import"   -> TokenType.IMPORT;
            case "nil"      -> TokenType.NIL;
            case "true"     -> TokenType.TRUE;
            case "false"    -> TokenType.FALSE;
            default         -> TokenType.IDENTIFIER;
        };
        addToken(type, text);
    }

    // ─── helpers ─────────────────────────────────────────────────────────────

    private boolean isAtEnd()  { return current >= source.length(); }
    private char    advance()  { return source.charAt(current++); }
    private char    peek()     { return isAtEnd() ? '\0' : source.charAt(current); }

    private boolean match(char expected) {
        if (isAtEnd() || source.charAt(current) != expected) return false;
        current++;
        return true;
    }

    private void addToken(TokenType type) {
        addToken(type, source.substring(start, current));
    }

    private void addToken(TokenType type, String value) {
        tokens.add(new Token(type, value, line, col()));
    }

    private boolean isDigit(char c)        { return c >= '0' && c <= '9'; }
    private boolean isAlpha(char c)        { return Character.isLetter(c) || c == '_'; }
    private boolean isAlphaNumeric(char c) { return isAlpha(c) || isDigit(c); }
}
