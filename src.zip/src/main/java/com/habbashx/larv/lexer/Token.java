package com.habbashx.larv.lexer;

/**
 * Immutable token produced by the Lexer.
 * Carries both line and column so errors can pinpoint the exact position.
 */
public record Token(TokenType tokenType, String value, int line, int column) {

    /** Synthetic token with no position (e.g. EOF). */
    public Token(TokenType tokenType, String value) {
        this(tokenType, value, -1, -1);
    }
}
