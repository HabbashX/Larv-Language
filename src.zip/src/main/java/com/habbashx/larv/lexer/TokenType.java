package com.habbashx.larv.lexer;

public enum TokenType {

    NUMBER,
    STRING,
    IDENTIFIER,

    VAR,
    CONST,
    STRING_KEYWORD,   // "string" keyword (your custom type keyword)
    PRINT,

    IF,
    ELSE,
    WHILE,
    FOR,
    FUNC,
    RETURN,

    PLUS,        // +
    MINUS,       // -
    STAR,        // *
    SLASH,       // /

    PLUS_PLUS,   // ++
    MINUS_MINUS, // --

    EQUAL,       // =
    EQEQ,        // ==
    NOTEQ,       // !=
    LT,          // <
    GT,          // >
    LTE,         // <=
    GTE,         // >=

    LPAREN,      // (
    RPAREN,      // )
    LBRACE,      // {
    RBRACE,      // }
    COMMA,       // ,
    SEMICOLON,   // ;
    LBRACKET,    // [
    RBRACKET,    // ]
    COLON,       // :

    BREAK,       // break
    CONTINUE,    // continue

    CLASS,

    INCLUDE,        // include keyword — binds a Java class to a Larv alias
    FROM,           // from    keyword — specifies the fully-qualified class name
    INVOLVE,        // involve keyword — supplies constructor arguments for an instance binding

    IMPORT,         // import keyword - supplies built in native or built in libraries

    NIL,         // nil — the null value
    TRUE,        // true boolean literal
    FALSE,       // false boolean literal

    DOT, NEW, THIS, EOF
}