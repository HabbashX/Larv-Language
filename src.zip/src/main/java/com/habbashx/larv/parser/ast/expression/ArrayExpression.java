package com.habbashx.larv.parser.ast.expression;

import java.util.List;

public record ArrayExpression(List<Expression> elements) implements Expression {
}
