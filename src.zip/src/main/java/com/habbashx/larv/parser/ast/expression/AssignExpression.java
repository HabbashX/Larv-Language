package com.habbashx.larv.parser.ast.expression;

public record AssignExpression(String name, Expression value) implements Expression {
}
