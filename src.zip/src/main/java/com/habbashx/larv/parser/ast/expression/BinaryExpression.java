package com.habbashx.larv.parser.ast.expression;

public record BinaryExpression(Expression left, String operator, Expression right) implements Expression {
}
