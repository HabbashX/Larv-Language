package com.habbashx.larv.parser.ast.expression;

public record BooleanExpression(boolean value) implements Expression {
}
