package com.habbashx.larv.parser.ast.expression;

import java.util.List;

public record CallExpression(Expression caller, List<Expression> arguments) implements Expression {
}
