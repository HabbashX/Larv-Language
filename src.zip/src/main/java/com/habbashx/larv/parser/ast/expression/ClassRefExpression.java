package com.habbashx.larv.parser.ast.expression;

public record ClassRefExpression(String name) implements Expression {
}
