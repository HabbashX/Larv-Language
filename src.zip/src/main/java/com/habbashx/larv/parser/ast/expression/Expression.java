package com.habbashx.larv.parser.ast.expression;

public sealed interface Expression
        permits ArrayExpression, AssignExpression, BinaryExpression, BooleanExpression, CallExpression, ClassRefExpression, GetExpression, GroupExpression, IndexExpression, JavaCallExpression, LiteralExpression, NewExpression, NumberExpression, SetExpression, StringExpression, ThisExpression, UnaryExpression, VarExpression {
}