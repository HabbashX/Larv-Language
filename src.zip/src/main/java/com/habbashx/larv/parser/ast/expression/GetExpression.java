package com.habbashx.larv.parser.ast.expression;

public record GetExpression(Expression object, String field) implements Expression {
}
