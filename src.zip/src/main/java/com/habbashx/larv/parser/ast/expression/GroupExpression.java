package com.habbashx.larv.parser.ast.expression;

public record GroupExpression(Expression expression) implements Expression {
}
