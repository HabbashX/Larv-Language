package com.habbashx.larv.parser.ast.expression;

public record IndexExpression(Expression array, Expression index) implements Expression {
}
