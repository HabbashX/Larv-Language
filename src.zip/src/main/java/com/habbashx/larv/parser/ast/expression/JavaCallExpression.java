package com.habbashx.larv.parser.ast.expression;

import java.util.List;

/**
 * Represents a Java FFI call: &lt;alias&gt;.&lt;methodName&gt;(arg1, arg2, ...)
 *
 * Example:
 *   Math.sqrt(9)
 *   System.currentTimeMillis()
 *
 * At runtime the interpreter resolves the alias → real Java Class via
 * reflection, then invokes the named static (or instance) method.
 */
public record JavaCallExpression(
        String alias,
        String methodName,
        List<Expression> arguments
) implements Expression {}
