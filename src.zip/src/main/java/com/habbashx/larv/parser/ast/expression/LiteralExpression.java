package com.habbashx.larv.parser.ast.expression;

public record LiteralExpression(Object value) implements Expression {
}
