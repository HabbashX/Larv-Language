package com.habbashx.larv.parser.ast.expression;

import java.util.List;

public record NewExpression(String className, List<Expression> args) implements Expression {
}
