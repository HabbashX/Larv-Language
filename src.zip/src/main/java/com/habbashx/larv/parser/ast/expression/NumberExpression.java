package com.habbashx.larv.parser.ast.expression;

/**
 * All Larv numbers are stored as Double at runtime.
 * This avoids constant int↔double coercion and keeps arithmetic consistent
 * with values returned from Java FFI calls (which normalize to Double).
 */
public record NumberExpression(double value) implements Expression {}
