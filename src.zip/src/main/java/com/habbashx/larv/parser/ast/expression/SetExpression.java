package com.habbashx.larv.parser.ast.expression;

public record SetExpression(Expression object, String field, Expression value) implements Expression {
}
