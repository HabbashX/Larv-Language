package com.habbashx.larv.parser.ast.expression;

public record StringExpression(String value) implements Expression {
}
