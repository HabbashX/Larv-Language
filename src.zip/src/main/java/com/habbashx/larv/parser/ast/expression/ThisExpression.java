package com.habbashx.larv.parser.ast.expression;

public record ThisExpression() implements Expression {
}
