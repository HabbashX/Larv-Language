package com.habbashx.larv.parser.ast.expression;

public record UnaryExpression(String operator, Expression right) implements Expression {}