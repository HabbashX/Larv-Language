package com.habbashx.larv.parser.ast.expression;

public record VarExpression(String name) implements Expression {
}
