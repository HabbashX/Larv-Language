package com.habbashx.larv.parser.ast.expression.visitor;

import com.habbashx.larv.parser.ast.expression.*;

public interface ExpressionVisitor {
    Object visitNumber(NumberExpression expr);
    Object visitString(StringExpression expr);
    Object visitVar(VarExpression expr);
    Object visitBinary(BinaryExpression expr);
    Object visitCall(CallExpression expr);
    Object visitNew(NewExpression expr);
    Object visitThis(ThisExpression expr);
    Object visitGet(GetExpression expr);
    Object visitSet(SetExpression expr);
}