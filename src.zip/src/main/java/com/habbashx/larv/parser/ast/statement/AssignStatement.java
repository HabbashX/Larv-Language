package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

public record AssignStatement(String name , Expression value, int line) implements Statement {

}
