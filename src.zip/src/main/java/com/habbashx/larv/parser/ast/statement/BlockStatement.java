package com.habbashx.larv.parser.ast.statement;

import java.util.List;

public record BlockStatement(List<Statement> statements, int line) implements Statement {}