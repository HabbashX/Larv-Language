package com.habbashx.larv.parser.ast.statement;

public record BreakStatement(int line) implements Statement {
}
