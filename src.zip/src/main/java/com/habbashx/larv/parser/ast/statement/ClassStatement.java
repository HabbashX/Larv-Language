package com.habbashx.larv.parser.ast.statement;

import java.util.List;

public record ClassStatement(String name, List<Statement> body, int line) implements Statement {
}
