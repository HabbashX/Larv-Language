package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

public record ConstStatement(String name , Expression value, int line) implements Statement {
}
