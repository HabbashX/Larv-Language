package com.habbashx.larv.parser.ast.statement;

public record ContinueStatement(int line) implements Statement {
}
