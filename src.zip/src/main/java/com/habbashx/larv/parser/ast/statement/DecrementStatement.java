package com.habbashx.larv.parser.ast.statement;

public record DecrementStatement(String name, int line) implements Statement {
}
