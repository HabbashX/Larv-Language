package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

public record ExprStatement(Expression value, int line) implements Statement {
}
