package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

import java.util.List;

public record ForStatement(Statement init, Expression condition, Statement increment, List<Statement> body, int line) implements Statement {}