package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

import java.util.List;

public record ForeachStatement(
        String variable,
        Expression iterable,
        List<Statement> body,
        int line
) implements Statement {}