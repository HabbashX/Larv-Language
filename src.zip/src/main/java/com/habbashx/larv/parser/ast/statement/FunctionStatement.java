package com.habbashx.larv.parser.ast.statement;

import java.util.List;

public record FunctionStatement(String name, List<String> params, List<Statement> body, int line) implements Statement {}