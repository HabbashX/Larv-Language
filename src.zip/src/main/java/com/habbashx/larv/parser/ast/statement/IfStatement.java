package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

import java.util.List;

public record IfStatement(Expression condition , List<Statement> thenBranch , List<Statement> elseBranch, int line) implements Statement {
}
