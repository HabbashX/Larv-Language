package com.habbashx.larv.parser.ast.statement;

public record IncrementStatement(String name, int line) implements Statement {
}
