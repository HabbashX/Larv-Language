package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

public record IndexAssignStatement(Expression target, Expression index , Expression value, int line) implements Statement {
}
