package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

public record LetStatement(String name, Expression expression, int line) implements Statement {
}
