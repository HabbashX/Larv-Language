package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

public record PrintStatement(Expression value, int line) implements Statement {
}
