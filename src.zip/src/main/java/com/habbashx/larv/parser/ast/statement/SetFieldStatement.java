package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

public record SetFieldStatement(Expression object ,String field , Expression value, int line) implements Statement {
}
