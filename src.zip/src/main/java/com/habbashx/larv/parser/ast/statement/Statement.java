package com.habbashx.larv.parser.ast.statement;

public sealed interface Statement permits AssignStatement, BlockStatement, BreakStatement, ClassStatement, ConstStatement, ContinueStatement, DecrementStatement, ExprStatement, ForStatement, ForeachStatement, FunctionStatement, IfStatement, ImportStatement, IncrementStatement, IndexAssignStatement, JavaBindStatement, LetStatement, PrintStatement, ReturnStatement, SetFieldStatement, WhileStatement {

    /** Source line where this statement begins. -1 if unknown. */
    int line();
}
