package com.habbashx.larv.parser.ast.statement;

import com.habbashx.larv.parser.ast.expression.Expression;

import java.util.List;

public record WhileStatement(Expression condition, List<Statement> body, int line) implements Statement {}