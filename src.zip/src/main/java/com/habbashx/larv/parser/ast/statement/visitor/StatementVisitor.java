package com.habbashx.larv.parser.ast.statement.visitor;

import com.habbashx.larv.parser.ast.statement.*;

public interface StatementVisitor {
    void visitLet(LetStatement st);
    void visitConst(ConstStatement st);
    void visitAssign(AssignStatement st);
    void visitExpr(ExprStatement st);
    void visitPrint(PrintStatement st);
    void visitIf(IfStatement st);
    void visitWhile(WhileStatement st);
    void visitFor(ForStatement st);
    void visitBreak(BreakStatement st);
    void visitContinue(ContinueStatement st);
    void visitReturn(ReturnStatement st);
    void visitFunction(FunctionStatement st);
    void visitClass(ClassStatement st);
    void visitJavaBind(JavaBindStatement st);
}
