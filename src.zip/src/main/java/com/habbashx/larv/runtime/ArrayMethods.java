package com.habbashx.larv.runtime;

import com.habbashx.larv.error.LarvError;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayMethods {

    public static @Nullable Object dispatch(@NotNull List<Object> array,
                                            @NotNull String method,
                                            @NotNull List<Object> args) {
        return switch (method) {
            case "push"     -> { array.add(args.getFirst()); yield null; }
            case "pop"      -> {
                if (array.isEmpty()) throw new LarvError("pop() called on an empty array");
                yield array.removeLast();
            }
            case "peek"     -> {
                if (array.isEmpty()) throw new LarvError("peek() called on an empty array");
                yield array.getLast();
            }
            case "first"    -> {
                if (array.isEmpty()) throw new LarvError("first() called on an empty array");
                yield array.getFirst();
            }
            case "last"     -> {
                if (array.isEmpty()) throw new LarvError("last() called on an empty array");
                yield array.getLast();
            }
            case "contains" -> array.contains(args.getFirst());
            case "indexOf"  -> (double) array.indexOf(args.getFirst());
            case "isEmpty"  -> array.isEmpty();
            case "clear"    -> { array.clear(); yield null; }
            case "reverse"  -> { Collections.reverse(array); yield null; }
            case "remove"   -> {
                int idx = toIndex(args.getFirst(), "remove");
                if (idx < 0 || idx >= array.size())
                    throw new LarvError("remove() index " + idx + " is out of bounds — array has " + array.size() + " element(s)");
                yield array.remove(idx);
            }
            case "slice"    -> {
                int from = toIndex(args.get(0), "slice");
                int to   = toIndex(args.get(1), "slice");
                if (from > to)
                    throw new LarvError("slice() 'from' (" + from + ") must be <= 'to' (" + to + ")");
                if (from < 0 || to > array.size())
                    throw new LarvError("slice(" + from + ", " + to + ") is out of bounds — array has " + array.size() + " element(s)");
                yield new ArrayList<>(array.subList(from, to));
            }
            case "join"     -> {
                String sep = args.isEmpty() ? "" : BinaryOperator.stringify(args.get(0));
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < array.size(); i++) {
                    if (i > 0) sb.append(sep);
                    sb.append(BinaryOperator.stringify(array.get(i)));
                }
                yield sb.toString();
            }
            default -> throw new LarvError("Unknown array method '" + method + "' — available: push, pop, peek, first, last, contains, indexOf, isEmpty, clear, reverse, remove, slice, join");
        };
    }

    private static int toIndex(Object v, String method) {
        if (v instanceof Double d) return d.intValue();
        throw new LarvError(method + "() index must be a number, got: " + (v == null ? "nil" : v.getClass().getSimpleName()));
    }
}
