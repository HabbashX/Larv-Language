package com.habbashx.larv.runtime;

import com.habbashx.larv.error.LarvError;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Environment {

    private final Map<String, Object> values   = new HashMap<>();
    private final Set<String>         constants = new HashSet<>();
    private final Environment parent;

    public Environment()                 { this.parent = null; }
    public Environment(Environment p)    { this.parent = p; }

    public void define(String name, Object value) {
        values.put(name, value);
    }

    public void defineConst(String name, Object value) {
        values.put(name, value);
        constants.add(name);
    }

    public Object get(String name) {
        if (values.containsKey(name)) return values.get(name);
        if (parent != null)           return parent.get(name);
        throw new LarvError("Undefined variable '" + name + "'");
    }

    public void assign(String name, Object value) {
        if (constants.contains(name))
            throw new LarvError("Cannot reassign constant '" + name + "'");
        if (values.containsKey(name)) { values.put(name, value); return; }
        if (parent != null)           { parent.assign(name, value); return; }
        throw new LarvError("Undefined variable '" + name + "' — declare it with 'var' first");
    }
}
