package com.habbashx.larv.runtime;

import com.habbashx.larv.error.LarvError;
import com.habbashx.larv.parser.ast.statement.FunctionStatement;
import com.habbashx.larv.parser.ast.statement.Statement;
import com.habbashx.larv.signal.ReturnSignal;

import java.util.List;

public class FunctionInvoker {

    @FunctionalInterface
    public interface BlockRunner {
        void run(List<Statement> body);
    }

    private final ExecutionContext context;
    private BlockRunner blockRunner;

    public FunctionInvoker(ExecutionContext context) {
        this.context = context;
    }

    public void setBlockRunner(BlockRunner blockRunner) {
        this.blockRunner = blockRunner;
    }

    public Object invokeFunction(FunctionStatement fn, List<Object> args) {
        return withScope(() -> {
            bindParams(fn.params(), args);
            return captureReturn(fn.body());
        });
    }

    public Object invokeMethod(FunctionStatement fn, LarvObject self, List<Object> args) {
        return withScope(() -> {
            context.getEnvironment().define("this", self);
            bindParams(fn.params(), args);
            return captureReturn(fn.body());
        });
    }

    private Object withScope(java.util.concurrent.Callable<Object> action) {
        Environment saved = context.getEnvironment();
        context.pushScope();
        try {
            return action.call();
        } catch (LarvError e) {
            throw e;
        } catch (Exception e) {
            if (e instanceof RuntimeException re) throw re;
            throw new LarvError(e.getMessage());
        } finally {
            context.popScope(saved);
        }
    }

    private void bindParams(List<String> params, List<Object> args) {
        for (int i = 0; i < params.size(); i++) {
            context.getEnvironment().define(params.get(i), i < args.size() ? args.get(i) : null);
        }
    }

    private Object captureReturn(List<Statement> body) {
        try {
            blockRunner.run(body);
            return null;
        } catch (ReturnSignal r) {
            return r.value;
        }
    }
}
