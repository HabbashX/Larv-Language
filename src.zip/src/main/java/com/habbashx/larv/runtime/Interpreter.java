package com.habbashx.larv.runtime;

import com.habbashx.larv.parser.ast.statement.Statement;
import com.habbashx.larv.runtime.importer.LarvFileImporter;
import com.habbashx.larv.runtime.registry.NativeRegistry;

import java.nio.file.Path;
import java.util.List;

public class Interpreter {

    private final StatementExecutor executor;
    private final ExecutionContext  context;

    /**
     * @param projectRoot the directory from which file imports are resolved.
     *                    Pass the directory of the .larv file being executed.
     */
    public Interpreter(Path projectRoot) {
        context = new ExecutionContext();
        context.setProjectRoot(projectRoot);

        new NativeRegistry(context).registerAll();

        FunctionInvoker invoker = new FunctionInvoker(context);

        ExpressionEvaluator evaluator = new ExpressionEvaluator(context, invoker);

        executor = new StatementExecutor(context, evaluator);

        invoker.setBlockRunner(executor::runBlock);
    }

    public Interpreter() {
        this(Path.of(System.getProperty("user.dir")));
    }

    /** Runs a fully-parsed list of top-level statements. */
    public void execute(List<Statement> statements) {
        LarvFileImporter.reset();
        executor.execute(statements);
    }
}