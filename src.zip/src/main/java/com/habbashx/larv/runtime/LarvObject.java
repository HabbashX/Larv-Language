package com.habbashx.larv.runtime;


import com.habbashx.larv.runtime.call.LarvCallable;

import java.util.HashMap;
import java.util.Map;


public class LarvObject {

    private final Map<String, Object> fields = new HashMap<>();
    private final Map<String, LarvCallable> methods = new HashMap<>();

    public Object get(String name) {

        if (fields.containsKey(name)) {
            return fields.get(name);
        }

        LarvCallable method = methods.get(name);
        if (method != null) return method;

        throw new RuntimeException("Undefined field: " + name);
    }

    public void set(String name, Object value) {
        fields.put(name, value);
    }

    public void defineMethod(String name, LarvCallable fn) {
        methods.put(name, fn);
    }
}