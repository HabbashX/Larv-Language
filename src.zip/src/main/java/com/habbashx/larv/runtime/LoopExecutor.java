package com.habbashx.larv.runtime;


import com.habbashx.larv.signal.BreakSignal;
import com.habbashx.larv.signal.ContinueSignal;

import java.util.List;
import com.habbashx.larv.parser.ast.statement.Statement;
import org.jetbrains.annotations.NotNull;

public class LoopExecutor {

    @FunctionalInterface
    public interface BlockRunner {
        void run(List<Statement> body);
    }

    @FunctionalInterface
    public interface Condition {
        boolean test();
    }

    @FunctionalInterface
    public interface PostStep {
        void run();
    }

    private final BlockRunner blockRunner;

    public LoopExecutor(BlockRunner blockRunner) {
        this.blockRunner = blockRunner;
    }

    public void runWhile(Condition condition, List<Statement> body) {
        runLoop(condition, body, () -> {});
    }

    public void runFor(Condition condition, List<Statement> body, PostStep postStep) {
        runLoop(condition, body, postStep);
    }

    // ── Core loop ─────────────────────────────────────────────────────────────

    private void runLoop(@NotNull Condition condition, List<Statement> body, PostStep postStep) {
        while (condition.test()) {
            try {
                blockRunner.run(body);
            } catch (ContinueSignal ignored) {
                // skip to post-step and re-evaluate condition
            } catch (BreakSignal ignored) {
                break;
            }
            postStep.run();
        }
    }
}