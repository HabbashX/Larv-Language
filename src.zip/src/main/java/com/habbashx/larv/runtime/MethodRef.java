package com.habbashx.larv.runtime;

import com.habbashx.larv.parser.ast.statement.FunctionStatement;

public record MethodRef(LarvObject self , FunctionStatement fn) {
}
