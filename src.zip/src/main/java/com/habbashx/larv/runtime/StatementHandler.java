package com.habbashx.larv.runtime;

import com.habbashx.larv.parser.ast.statement.Statement;

/**
 * Executes a single {@link Statement} node.
 *
 * Each implementation owns exactly one statement form's runtime behaviour
 * (e.g. {@code let}, {@code if}, {@code while}).  Being a
 * {@link FunctionalInterface} means every handler can be expressed as a
 * concise method reference with no boilerplate wrapper class.
 *
 * The handler receives the raw {@link Statement} so it can downcast once,
 * cleanly, inside its own method — keeping the registry free of casts.
 */
@FunctionalInterface
public interface StatementHandler<T extends Statement> {
    void handle(T statement);
}
