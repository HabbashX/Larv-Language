package com.habbashx.larv.runtime;

/**
 * Decides whether a runtime value is considered truthy in Larv.
 *
 * Truthiness rules
 * ────────────────
 *   nil      →  false
 *   Boolean  →  its own value
 *   Integer  →  non-zero
 *   Double   →  non-zero
 *   String   →  non-empty
 *   anything else → true
 */
public final class TruthinessEvaluator {

    private TruthinessEvaluator() {}

    public static boolean isTruthy(Object value) {
        if (value == null)          return false;
        if (value instanceof Boolean b) return b;
        if (value instanceof Integer i) return i != 0;
        if (value instanceof Double d)  return d != 0.0;
        if (value instanceof String s)  return !s.isEmpty();
        return true;
    }
}
