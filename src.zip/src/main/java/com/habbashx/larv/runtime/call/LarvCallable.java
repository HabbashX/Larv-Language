package com.habbashx.larv.runtime.call;

import com.habbashx.larv.runtime.Interpreter;

import java.util.List;

public interface LarvCallable {

    Object call(Interpreter interpreter, List<Object> args);

}
