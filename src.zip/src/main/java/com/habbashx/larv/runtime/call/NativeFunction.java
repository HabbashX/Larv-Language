package com.habbashx.larv.runtime.call;

import com.habbashx.larv.runtime.Interpreter;

import java.util.List;
import java.util.function.Function;

public class NativeFunction implements LarvCallable {

    private final Function<List<Object>, Object> fn;

    public NativeFunction(Function<List<Object>, Object> fn) {
        this.fn = fn;
    }

    @Override
    public Object call(Interpreter interpreter, List<Object> args) {
        return fn.apply(args);
    }
}