package com.habbashx.larv.runtime.call;


import com.habbashx.larv.runtime.Environment;
import com.habbashx.larv.runtime.Interpreter;
import com.habbashx.larv.signal.ReturnSignal;

import java.util.List;


import com.habbashx.larv.parser.ast.statement.FunctionStatement;


public class UserFunction implements LarvCallable {

    private final FunctionStatement fn;
    private final Environment closure;

    public UserFunction(FunctionStatement fn, Environment closure) {
        this.fn = fn;
        this.closure = closure;
    }

    @Override
    public Object call(Interpreter interpreter, List<Object> args) {

        Environment env = new Environment(closure);

        for (int i = 0; i < fn.params().size(); i++) {
            env.define(fn.params().get(i), args.get(i));
        }

        try {
        } catch (ReturnSignal r) {
            return r.value;
        }

        return null;
    }
}