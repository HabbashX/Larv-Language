package com.habbashx.larv.runtime.registry;


import com.habbashx.larv.runtime.ExecutionContext;
import com.habbashx.larv.runtime.BinaryOperator;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Registers all native (built-in) functions into the {@link ExecutionContext}.
 *
 * Adding a new built-in means adding one line here — nothing else changes.
 */
public class NativeRegistry {

    private final ExecutionContext context;

    private final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    public NativeRegistry(ExecutionContext context) {
        this.context = context;
    }

    public void registerAll() {
        context.registerNative("print",   this::nativePrint);
        context.registerNative("input", this::nativeInput);
        context.registerNative("len",    this::nativeLen);
    }

    private @Nullable Object nativePrint(@NotNull List<Object> args) {
        System.out.println(BinaryOperator.stringify(args.getFirst()));
        return null;
    }

    private @Unmodifiable Object nativeInput(List<Object> args) {
        try {
            return reader.readLine();
        } catch (IOException e) {
            throw new RuntimeException("input failed: " + e.getMessage(), e);
        }
    }

    private @NotNull @Unmodifiable Object nativeLen(@NotNull List<Object> args) {
        Object value = args.getFirst();
        if (value instanceof List<?> list) return list.size();
        throw new RuntimeException("len() expects an array, got: " + value.getClass().getSimpleName());
    }
}