package com.habbashx.larv.signal;

public class BreakSignal extends RuntimeException {
}
