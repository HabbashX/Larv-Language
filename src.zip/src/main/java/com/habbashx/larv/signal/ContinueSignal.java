package com.habbashx.larv.signal;

public class ContinueSignal extends RuntimeException {
}
